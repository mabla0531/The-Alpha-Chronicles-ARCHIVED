#include "Game.h"

int main() {
    startGame();

    return 0;
}
