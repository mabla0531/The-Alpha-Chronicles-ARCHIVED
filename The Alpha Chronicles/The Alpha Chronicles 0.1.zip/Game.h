#pragma once

void startGame();