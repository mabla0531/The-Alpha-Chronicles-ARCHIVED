#include "State.h"

bool State::isFinished() {
	return finished;
}